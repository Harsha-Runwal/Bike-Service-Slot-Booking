package com.bssb.imageControl;

public class fileResponse {

	String fileName;
	String message;
	public fileResponse(String fileName, String message) {
		super();
		this.fileName = fileName;
		this.message = message;
	}

	public fileResponse() {
		super();
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}



}
	