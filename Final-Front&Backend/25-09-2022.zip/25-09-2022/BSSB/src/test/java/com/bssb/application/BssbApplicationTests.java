package com.bssb.application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BssbApplicationTests {

	@Test
	void contextLoads() {
	}

}
